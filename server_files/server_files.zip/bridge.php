<?php
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

$action = $_GET['action'] ?? 'dashboard';
$cache_dir = __DIR__ . '/cache';

if (!is_dir($cache_dir)) {
    mkdir($cache_dir, 0777, true);
}

if ($action === 'dashboard') {
    $response = [
        "slider" => [
            ["id" => "1", "title" => "Yeni Hekayələr", "image" => "https://olibrary.space/banner.jpg"]
        ],
        "category" => [
            ["id" => "1", "name" => "Romantika", "logo" => ""],
            ["id" => "2", "name" => "Xəyal", "logo" => ""]
        ],
        "latest_book" => [
            [
                "id" => "12345678",
                "name" => "Mənim Nümunə Kitabım",
                "category_id" => "1",
                "authorName" => "Yazar Adı",
                "logo" => "https://img.wattpad.com/cover/12345678-256-k123456.jpg",
                "is_premium" => "1",
                "coin_price" => 15,
                "type" => "pdf",
                "file" => "https://olibrary.space/bridge.php?action=read&id=12345678",
                "description" => "Bu kitab kənar bazadan (Addon) dinamik olaraq çəkilmişdir."
            ]
        ]
    ];
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'search') {
    $q = $_GET['q'] ?? '';
    // Əsl sistemdə Wattpad axtarış API-sinə cURL edilib nəticələr qaytarılmalıdır.
    $response = [
        "data" => [
            [
                 "id" => "search_1",
                 "name" => "Axtarış: " . $q,
                 "authorName" => "Naməlum Yazar",
                 "logo" => "",
                 "is_premium" => "0",
                 "type" => "pdf"
            ]
        ]
    ];
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'read') {
    $id = $_GET['id'] ?? '';
    if (empty($id)) {
        echo json_encode(["error" => "No ID provided"]);
        exit;
    }
    
    $pdf_file = $cache_dir . '/' . $id . '.pdf';
    $pdf_url = "https://olibrary.space/cache/" . $id . ".pdf";
    
    if (file_exists($pdf_file)) {
        header("Location: " . $pdf_url);
        exit;
    }
    
    // Python skriptini işə sal
    // $command = escapeshellcmd("python3 gen_pdf.py " . escapeshellarg($id) . " " . escapeshellarg($pdf_file));
    // exec($command, $output, $return_var);
    
    // Test üçün dummy PDF yaradırıq (canlıda yuxarıdakı python çağırılmalıdır)
    $dummy_pdf = "%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
    file_put_contents($pdf_file, $dummy_pdf);
    
    header("Location: " . $pdf_url);
    exit;
}

echo json_encode(["error" => "Invalid action"]);
?>
