import sys
import os
import requests
from fpdf import FPDF
import time

def log_error(msg):
    with open("pdf_error_log.txt", "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - {msg}\n")

if len(sys.argv) < 3:
    print("Usage: python3 gen_pdf.py <book_id> <output_path>")
    sys.exit(1)

book_id = sys.argv[1]
output_path = sys.argv[2]

# --- NÜMUNƏ: WATTPAD API-DƏN HİSSƏLƏRİ ÇƏKMƏ MƏNTİQİ ---
# Qeyd: Bu, sadələşdirilmiş bir skriptdir. Əsl sistemdə Wattpad'ın
# api.wattpad.com/v4/parts endpointsindən istifadə edilməlidir.

class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 15)
        self.cell(0, 10, 'Açıq Qaynaq Addon - Litrex', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Səhifə {self.page_no()}', 0, 0, 'C')

try:
    pdf = PDF()
    pdf.add_page()
    pdf.add_font("DejaVu", "", "DejaVuSans.ttf", uni=True) # FPDF uçun UTF-8 font
    pdf.set_font("DejaVu", size=12)

    # Bura API-dən mətnin çəkilməsi kodu yazılacaq
    # Dummy mətn:
    pdf.multi_cell(0, 10, "Bu kitab Addon sistemi vasitəsilə dinamik olaraq skrap edilib.")
    pdf.ln()
    pdf.multi_cell(0, 10, f"Axtarılan Kitab ID: {book_id}")

    pdf.output(output_path)
    print(f"PDF successfully generated: {output_path}")

except Exception as e:
    log_error(str(e))
    sys.exit(1)
